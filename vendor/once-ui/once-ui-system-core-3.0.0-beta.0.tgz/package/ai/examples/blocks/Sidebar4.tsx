"use client";

import {
  Avatar,
  Column,
  Fade,
  IconButton,
  Line,
  Media,
  Row,
  Scroller,
  Text,
  ToggleButton,
} from "@once-ui-system/core";
import { useState } from "react";
import { sidebar } from "./content/chat1content";

export const Sidebar4: React.FC<
  React.ComponentProps<typeof Column> & {
    activeItem?: string;
    onSelectItem?: (label: string) => void;
  }
> = ({ activeItem, onSelectItem, ...flex }) => {
  const [activeRoom, setActiveRoom] = useState<string | null>("👋 ┃ intro");

  return (
    <Column fillHeight maxWidth="18rem" background="surface" {...flex}>
      <Row fillWidth aspectRatio="2/1">
        <Media src="/images/blocks/vibe-coding-dark.jpg" stretch sizes="240px" />
        <Fade position="absolute" top="0" fillWidth height="6rem" opacity={70} />
        <Row
          fillWidth
          paddingY="12"
          paddingX="24"
          position="absolute"
          top="0"
          textVariant="label-strong-s"
          horizontal="center"
          align="center"
        >
          Design Engineers Club
        </Row>
      </Row>
      <Scroller fillHeight direction="column">
        <Column fillWidth padding="8">
          <Column fillWidth gap="2">
            {(sidebar.find((s) => s.items)?.items ?? []).map((item, idx) => {
              const selected = activeRoom === null && !!activeItem && item.label === activeItem;
              return (
                <ToggleButton
                  key={idx}
                  fillWidth
                  horizontal="start"
                  selected={selected}
                  onClick={() => {
                    setActiveRoom(null);
                    onSelectItem?.(item.label);
                  }}
                >
                  {item.label}
                </ToggleButton>
              );
            })}
          </Column>
          <Line background="neutral-alpha-weak" marginY="12" />
          <Column fillWidth gap="24">
            {sidebar
              .filter((s) => s.title)
              .map((section, sIdx) => (
                <Column key={sIdx} fillWidth gap="2">
                  <Text
                    textVariant="label-default-s"
                    onBackground="neutral-weak"
                    marginLeft="16"
                    marginTop="4"
                    marginBottom="8"
                  >
                    {section.title ?? ""}
                  </Text>
                  {(section.rooms ?? []).map((room, rIdx) => {
                    const selected = room.label === activeRoom;
                    return (
                      <ToggleButton
                        key={rIdx}
                        fillWidth
                        horizontal="start"
                        selected={selected}
                        onClick={() => {
                          setActiveRoom(room.label);
                          onSelectItem?.(""); // clear top-level selection
                        }}
                      >
                        <Text weight="strong" onBackground={selected ? undefined : "neutral-weak"}>
                          {room.label}
                        </Text>
                      </ToggleButton>
                    );
                  })}
                </Column>
              ))}
          </Column>
        </Column>
      </Scroller>
      <Row fillWidth padding="8">
        <Row
          fillWidth
          vertical="center"
          padding="12"
          radius="l"
          gap="16"
          background="neutral-alpha-weak"
        >
          <Avatar src="/images/creators/lorant.jpg" statusIndicator={{ scheme: "green" }} />
          <Column fillWidth gap="2">
            <Text textVariant="label-strong-s" truncate>
              Lorant
            </Text>
            <Text textVariant="body-default-xs" onBackground="neutral-weak" truncate>
              Coding something...
            </Text>
          </Column>
          <IconButton icon="settings" variant="secondary" tooltip="User settings" />
        </Row>
      </Row>
    </Column>
  );
};
