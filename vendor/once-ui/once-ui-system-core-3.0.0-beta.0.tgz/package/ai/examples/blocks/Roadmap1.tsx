import { Card, Column, Heading, Row, StatusIndicator, Text, User } from "@once-ui-system/core";
import { roadmap, task } from "./content/roadmap1content";

export interface Task {
  title: string;
  description?: string;
  user?: {
    name?: string;
    avatar?: string;
  };
  href?: string;
  type?: keyof typeof task;
}

const RoadmapTask = ({ task: taskItem }: { task: Task }) => (
  <Column gap="8" fillWidth>
    <Text align="left" onBackground="neutral-strong" textVariant="body-strong-m">
      {taskItem.title}
    </Text>

    {taskItem.description && (
      <Text align="left" textVariant="body-default-s" onBackground="neutral-weak">
        {taskItem.description}
      </Text>
    )}

    {(taskItem.user || taskItem.type) && (
      <Row marginTop="8" fillWidth vertical="center" horizontal="between">
        {taskItem.user && (
          <User
            avatarProps={{
              size: "s",
              src: taskItem.user.avatar,
              empty: !taskItem.user.avatar,
            }}
          >
            <Row paddingLeft="4" textVariant="label-default-s">
              {taskItem.user.name}
            </Row>
          </User>
        )}
        {taskItem.type && (
          <Row vertical="center" gap="8">
            <StatusIndicator scheme={task[taskItem.type].color} />
            <Text onBackground="neutral-weak" textVariant="label-default-s">
              {task[taskItem.type].label}
            </Text>
          </Row>
        )}
      </Row>
    )}
  </Column>
);

export function Roadmap1() {
  return (
    <Column maxWidth="l" as="main">
      <Column fillWidth gap="12" paddingBottom="l" paddingX="8">
        <Heading textVariant="display-strong-s">Roadmap</Heading>
        <Text
          wrap="balance"
          onBackground="neutral-weak"
          textVariant="body-default-xl"
          marginBottom="20"
        >
          List of features planned for Q4 2025
        </Text>
      </Column>

      {roadmap.map((product, productIndex) => (
        <Column key={productIndex} gap="24" marginTop={productIndex > 0 ? "48" : "0"} fillWidth>
          {product.product && (
            <Row gap="16" marginBottom="16" vertical="center" fillWidth>
              <Row minWidth="40" width="40" height="40" padding="8" vertical="center">
                <Row
                  radius="full"
                  fillWidth
                  minHeight="4"
                  solid="brand-medium"
                  data-brand={product.brand}
                  themeSolid="inverse"
                />
              </Row>
              <Heading as="h2" textVariant="display-default-xs">
                {product.product}
              </Heading>
            </Row>
          )}

          <Row gap="4" fillWidth overflowX="auto" paddingBottom="16">
            {product.columns.map((column, columnIndex) => (
              <Column
                key={columnIndex}
                padding="4"
                gap="4"
                radius="s-4"
                border
                background="overlay"
                fillWidth
                minWidth="20rem"
              >
                <Row fillWidth vertical="center" gap="8" paddingY="8" paddingX="16">
                  <Text textVariant="label-default-m">{column.title}</Text>
                  <Text textVariant="label-default-s" onBackground="neutral-weak">
                    {column.tasks.length}
                  </Text>
                </Row>

                <Column gap="4" fillWidth>
                  {column.tasks.map((taskItem, taskIndex) =>
                    taskItem.href ? (
                      <Card
                        onBackground="neutral-strong"
                        border
                        fillWidth
                        radius="s"
                        key={taskIndex}
                        href={taskItem.href}
                        padding="16"
                      >
                        <RoadmapTask task={taskItem} />
                      </Card>
                    ) : (
                      <Column
                        onBackground="neutral-strong"
                        border
                        fillWidth
                        radius="s"
                        key={taskIndex}
                        padding="16"
                        gap="8"
                      >
                        <RoadmapTask task={taskItem} />
                      </Column>
                    ),
                  )}
                </Column>
              </Column>
            ))}
          </Row>
        </Column>
      ))}
    </Column>
  );
}
