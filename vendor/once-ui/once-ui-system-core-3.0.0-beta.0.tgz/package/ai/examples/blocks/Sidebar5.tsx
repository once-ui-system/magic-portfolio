import {
  Avatar,
  Card,
  Column,
  Dropdown,
  Heading,
  IconButton,
  Media,
  Row,
  Text,
} from "@once-ui-system/core";
import { chatMembers } from "./content/chat1content";

export const Sidebar5: React.FC<React.ComponentProps<typeof Column>> = ({ ...flex }) => {
  return (
    <Column fillHeight maxWidth="18rem" background="surface" gap="20" {...flex}>
      <Row paddingX="24" paddingTop="12">
        <Heading as="h2" textVariant="label-strong-m">
          Members
        </Heading>
      </Row>
      <Column fill gap="32" data-scaling="90" paddingX="12" paddingBottom="16" overflowY="auto">
        {chatMembers.map((group, gIndex) => (
          <Column key={gIndex} fillWidth gap="2">
            <Row
              vertical="center"
              gap="8"
              paddingLeft="16"
              textVariant="label-default-s"
              onBackground="neutral-weak"
              paddingBottom="4"
            >
              <Text>{group.title}</Text>
              <Row width="4" height="4" radius="full" background="neutral-strong" />
              <Text>{group.members.length}</Text>
            </Row>
            {group.members.map((member, index) => (
              <Dropdown
                fillWidth
                key={index}
                placement="left-start"
                trigger={
                  <Card
                    paddingY="8"
                    paddingX="16"
                    border="transparent"
                    background="transparent"
                    radius="m"
                    key={index}
                    fillWidth
                    gap="16"
                    vertical="center"
                  >
                    <Avatar src={member.avatar} statusIndicator={{ scheme: member.statusColor }} />
                    <Column fillWidth gap="2">
                      <Text textVariant="label-strong-s" truncate>
                        {member.name}
                      </Text>
                      {member.status && (
                        <Text textVariant="body-default-xs" onBackground="neutral-weak" truncate>
                          {member.status}
                        </Text>
                      )}
                    </Column>
                  </Card>
                }
              >
                <Column maxWidth="20rem" fitHeight tabIndex={-1}>
                  <Row fillWidth>
                    <Media src="/images/backgrounds/1.jpg" sizes="320px" aspectRatio="2/1" />
                    <Row position="absolute" right="12" top="12" themeBorder="rounded" gap="8">
                      <IconButton icon="personRemove" tooltip="Remove" tooltipPosition="bottom" />
                      <IconButton icon="settings" tooltip="Settings" tooltipPosition="bottom" />
                    </Row>
                    <Avatar
                      position="absolute"
                      left="12"
                      bottom="0"
                      src={member.avatar}
                      size="6rem"
                      statusIndicator={{ scheme: member.statusColor }}
                      style={{
                        transform: "translate(0, 50%)",
                        borderWidth: 4,
                        borderColor: "var(--surface-border)",
                      }}
                    />
                  </Row>
                  <Column fillWidth padding="20" marginTop="40" gap="12">
                    <Column fillWidth gap="2">
                      <Text textVariant="heading-strong-s">{member.name}</Text>
                      <Text textVariant="body-default-xs" onBackground="neutral-weak">
                        {member.status}
                      </Text>
                    </Column>
                    {member.bio && (
                      <Row fillWidth textVariant="body-default-xs" onBackground="neutral-weak">
                        {member.bio}
                      </Row>
                    )}
                  </Column>
                </Column>
              </Dropdown>
            ))}
          </Column>
        ))}
      </Column>
    </Column>
  );
};
